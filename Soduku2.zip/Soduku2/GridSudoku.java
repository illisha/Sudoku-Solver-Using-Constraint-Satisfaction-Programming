/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Soduku2;

/**
 *
 * @author PC
 */
import static Soduku2.SudokuApp.TEST;
import static Soduku2.SudokuApp.grid;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Scanner;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;
import javax.swing.border.Border;


final class GridSudoku extends JPanel {

    private static final Font FONT = new Font("Verdana",
            Font.CENTER_BASELINE,
            25);

    private final JTextField[][] grid;
    private final Map<JTextField, Point> mapFieldToCoordinates
            = new HashMap<>();

    private final int dimension;
    private final JPanel gridPanel;
    private final JPanel buttonPanel;
    private final JButton solveButton;
    private final JButton clearButton;
    private final JPanel[][] minisquarePanels;
    
    public String text = new String();
    public int flag = 0;

    GridSudoku(int dimension) {
        this.grid = new JTextField[dimension][dimension];
        this.dimension = dimension;

        for (int y = 0; y < dimension; ++y) {
            for (int x = 0; x < dimension; ++x) {
                JTextField field = new JTextField();
                field.addKeyListener(new SudokuCellKeyListener(this));
                mapFieldToCoordinates.put(field, new Point(x, y));
                grid[y][x] = field;
            }
        }

        this.gridPanel = new JPanel();
        this.buttonPanel = new JPanel();

        Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
        Dimension fieldDimension = new Dimension(50, 50);

        class PopupMenuListener implements ActionListener {

            private final JTextField field;
            private final int number;

            PopupMenuListener(JTextField field, int number) {
                this.field = field;
                this.number = number;
            }

            @Override
            public void actionPerformed(ActionEvent e) {
                field.setText("" + number);
            }
        }

        for (int y = 0; y < dimension; ++y) {
            for (int x = 0; x < dimension; ++x) {
                JTextField field = grid[y][x];
                field.setBorder(border);
                field.setFont(FONT);
                field.setHorizontalAlignment(JTextField.CENTER);
                field.setPreferredSize(fieldDimension);

                JPopupMenu menu = new JPopupMenu();

                for (int i = 0; i <= dimension; ++i) {
                    JMenuItem item = new JMenuItem("" + i);
                    menu.add(item);
                    item.addActionListener(new PopupMenuListener(field, i));
                }

                field.add(menu);
                field.setComponentPopupMenu(menu);
            }
        }

        int minisquareDimension = (int) Math.sqrt(dimension);
        this.gridPanel.setLayout(new GridLayout(minisquareDimension,
                minisquareDimension));

        this.minisquarePanels = new JPanel[minisquareDimension][minisquareDimension];

        Border minisquareBorder = BorderFactory.createLineBorder(Color.BLUE, 2);

        for (int y = 0; y < minisquareDimension; ++y) {
            for (int x = 0; x < minisquareDimension; ++x) {
                JPanel panel = new JPanel();
                panel.setLayout(new GridLayout(minisquareDimension,
                        minisquareDimension));
                panel.setBorder(minisquareBorder);
                minisquarePanels[y][x] = panel;
                gridPanel.add(panel);
            }
        }

        for (int y = 0; y < dimension; ++y) {
            for (int x = 0; x < dimension; ++x) {
                int minisquareX = x / minisquareDimension;
                int minisquareY = y / minisquareDimension;

                minisquarePanels[minisquareY][minisquareX].add(grid[y][x]);
            }
        }

        this.gridPanel.setBorder(BorderFactory.createLineBorder(Color.CYAN,
                3));
        this.clearButton = new JButton("Clear");
        this.solveButton = new JButton("Solve");

        this.buttonPanel.setLayout(new BorderLayout());
        this.buttonPanel.add(clearButton, BorderLayout.WEST);
        this.buttonPanel.add(solveButton, BorderLayout.EAST);

        this.setLayout(new BorderLayout());
        this.add(gridPanel, BorderLayout.NORTH);
        this.add(buttonPanel, BorderLayout.SOUTH);

        solveButton.addActionListener((ActionEvent e) -> {
            solve();
        });
        clearButton.addActionListener((ActionEvent e) -> {
            clearAll();
        });

    }
    
    GridSudoku(int dimension, String TEST) {
        this.grid = new JTextField[dimension][dimension];
        this.dimension = dimension;

        for (int y = 0; y < dimension; ++y) {
            for (int x = 0; x < dimension; ++x) {
                JTextField field = new JTextField();
                field.addKeyListener(new SudokuCellKeyListener(this));
                mapFieldToCoordinates.put(field, new Point(x, y));
                grid[y][x] = field;
            }
        }

        this.gridPanel = new JPanel();
        this.buttonPanel = new JPanel();

        Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
        Dimension fieldDimension = new Dimension(50, 50);

        class PopupMenuListener implements ActionListener {

            private final JTextField field;
            private final int number;

            PopupMenuListener(JTextField field, int number) {
                this.field = field;
                this.number = number;
            }

            @Override
            public void actionPerformed(ActionEvent e) {
                field.setText("" + number);
            }
        }

        for (int y = 0; y < dimension; ++y) {
            for (int x = 0; x < dimension; ++x) {
                JTextField field = grid[y][x];
                field.setBorder(border);
                field.setFont(FONT);
                field.setHorizontalAlignment(JTextField.CENTER);
                field.setPreferredSize(fieldDimension);

                JPopupMenu menu = new JPopupMenu();

                for (int i = 0; i <= dimension; ++i) {
                    JMenuItem item = new JMenuItem("" + i);
                    menu.add(item);
                    item.addActionListener(new PopupMenuListener(field, i));
                }

                field.add(menu);
                field.setComponentPopupMenu(menu);
            }
        }

        int minisquareDimension = (int) Math.sqrt(dimension);
        this.gridPanel.setLayout(new GridLayout(minisquareDimension,
                minisquareDimension));

        this.minisquarePanels = new JPanel[minisquareDimension][minisquareDimension];

        Border minisquareBorder = BorderFactory.createLineBorder(Color.BLUE, 2);

        for (int y = 0; y < minisquareDimension; ++y) {
            for (int x = 0; x < minisquareDimension; ++x) {
                JPanel panel = new JPanel();
                panel.setLayout(new GridLayout(minisquareDimension,
                        minisquareDimension));
                panel.setBorder(minisquareBorder);
                minisquarePanels[y][x] = panel;
                gridPanel.add(panel);
            }
        }

        for (int y = 0; y < dimension; ++y) {
            for (int x = 0; x < dimension; ++x) {
                int minisquareX = x / minisquareDimension;
                int minisquareY = y / minisquareDimension;

                minisquarePanels[minisquareY][minisquareX].add(grid[y][x]);
            }
        }
        
        int i=0;
        for (int y = 0; y < dimension; ++y) {
            for (int x = 0; x < dimension; ++x) {
                if(TEST.charAt(i)!='0')
                grid[y][x].setText("" + TEST.charAt(i));
                else
                    grid[y][x].setText("");
                i++;
            }
        }
        this.repaint();
        
        this.gridPanel.setBorder(BorderFactory.createLineBorder(Color.CYAN,
                3));
        this.clearButton = new JButton("Clear");
        this.solveButton = new JButton("Solve");

        this.buttonPanel.setLayout(new BorderLayout());
        this.buttonPanel.add(clearButton, BorderLayout.WEST);
        this.buttonPanel.add(solveButton, BorderLayout.EAST);

        this.setLayout(new BorderLayout());
        this.add(gridPanel, BorderLayout.NORTH);
        this.add(buttonPanel, BorderLayout.SOUTH);

        solveButton.addActionListener((ActionEvent e) -> {
            solve();
        });
        clearButton.addActionListener((ActionEvent e) -> {
            clearAll();
        });

    }

    int getDimension() {
        return dimension;
    }

    /*void openFile(File file) {
        try {
            Scanner scanner = new Scanner(file);
            clearAll();
            System.out.println("you are here safe");
            int cells = dimension * dimension;
            int y = 0;
            int x = 0;

            while (cells > 0) {
                if (scanner.hasNext()) {
                    String text = scanner.next();

                    try {
                        int number = Integer.parseInt(text);

                        if (number > 0 && number <= dimension) {
                            grid[y][x].setText(" " + number);
                        }
                        flag = 1;
                        
                    } catch (NumberFormatException ex) {

                    }

                    ++x;

                    if (x == dimension) {
                        x = 0;
                        ++y;
                    }
                } else {
                    break;
                }

                --cells;
            }
        } catch (FileNotFoundException ex) {

        }
    }*/

    private void addSpace(JTextField field) {
        if (field.getText().isEmpty()) {
            field.setText(" ");
        }
    }

    void moveCursor(JTextField field, char c) {
        Point coordinates = mapFieldToCoordinates.get(field);
        field.setBackground(Color.yellow);

        switch (c) {
            case 'w':
            case 'W':

                if (coordinates.y > 0) {
                    grid[coordinates.y - 1][coordinates.x].requestFocus();
                    addSpace(grid[coordinates.y - 1][coordinates.x]);
                }

                break;

            case 'd':
            case 'D':

                if (coordinates.x < dimension - 1) {
                    grid[coordinates.y][coordinates.x + 1].requestFocus();
                    addSpace(grid[coordinates.y][coordinates.x + 1]);
                }

                break;

            case 's':
            case 'S':

                if (coordinates.y < dimension - 1) {
                    grid[coordinates.y + 1][coordinates.x].requestFocus();
                    addSpace(grid[coordinates.y + 1][coordinates.x]);
                }

                break;

            case 'a':
            case 'A':

                if (coordinates.x > 0) {
                    grid[coordinates.y][coordinates.x - 1].requestFocus();
                    addSpace(grid[coordinates.y][coordinates.x - 1]);
                }

                break;
        }
    }

    void clearAll() {
        for (JTextField[] row : grid) {
            for (JTextField field : row) {
                field.setText("");
            }
        }
    }

    public void solve() {
        int count = 1;
        for (int y = 0; y < dimension; ++y) {
            for (int x = 0; x < dimension; ++x) {
                if (!grid[y][x].getText().equals("")) {
                    text = text + grid[y][x].getText();
                } else {
                    text = text + '0';
                }
                count++;
                if(count==10 && y<dimension-1)
                {
                    text = text + "\n";
                    count = 1;
                }
            }
            
        }
        //System.out.println(text);
        
        TEST = text;
        long start = System.nanoTime();
        DFSSolver<Integer> solver = new DFSSolver<>(new MinimumRemainingValue<>());
        solver.addListener(state -> PrintFixed.printBoard(state));
        Optional<Assignment<Integer>> completeAssignment = solver.solve(new SudokuCSP(TEST));
        long end = System.nanoTime();
        long duration = (end - start) / 1000000;
        completeAssignment.orElseThrow(() -> new RuntimeException("Found no solution."));
        completeAssignment.ifPresent(assignment -> {
            System.out.println("Took " + duration + " ms.");
            System.out.println();
            String temp = PrintFixed.printBoard(assignment);
            showfinal(temp);
        });
        
    }
    
    public void solve(String TEST) {
        
        
        
        long start = System.nanoTime();
        DFSSolver<Integer> solver = new DFSSolver<>(new MinimumRemainingValue<>());
        solver.addListener(state -> PrintFixed.printBoard(state));
        Optional<Assignment<Integer>> completeAssignment = solver.solve(new SudokuCSP(TEST));
        long end = System.nanoTime();
        long duration = (end - start) / 1000000;
        completeAssignment.orElseThrow(() -> new RuntimeException("Found no solution."));
        completeAssignment.ifPresent(assignment -> {
            System.out.println("Took " + duration + " ms.");
            System.out.println();
            String temp = PrintFixed.printBoard(assignment);
            showfinal(temp);
        });
        
    }
    
    
    
    public void showfinal(String temp){
        int i=0;
        for (int y = 0; y < dimension; ++y) {
            for (int x = 0; x < dimension; ++x) {
                grid[y][x].setText("" + temp.charAt(i));
                i++;
            }
        }
    }
    public String getStr(){
        return text;
    }
    
}
