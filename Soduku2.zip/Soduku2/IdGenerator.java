package Soduku2;

import Soduku2.VariableIdentity;

import static Soduku2.VariableIdentity.id;

public class IdGenerator {

    public static VariableIdentity identityOfVariableAt(final int row, final int col) {
        return id(String.format("C%s%s", String.valueOf(row), String.valueOf(col)));
    }
}