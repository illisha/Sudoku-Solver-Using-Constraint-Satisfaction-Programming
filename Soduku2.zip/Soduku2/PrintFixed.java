package Soduku2;

import Soduku2.Assignment;
import static Soduku2.SudokuApp.grid;
import Soduku2.VariableIdentity;
import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JFrame;

public class PrintFixed {
    private static final JFrame frame = new JFrame("Sudoku solver");
    

    public static String printBoard(final Assignment<Integer> assignment) {
        final StringBuilder sb = new StringBuilder();
        String s = new String();
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                final VariableIdentity id = IdGenerator.identityOfVariableAt(row, col);
                final String assignedValue = assignment.valueOf(id) == null ? "." : String.valueOf(assignment.valueOf(id));
                sb.append(assignedValue + " ");
                s = s+assignedValue; 
            }
            sb.append("\n");
        }
        System.out.println(sb.toString());
        return s;
    }
}