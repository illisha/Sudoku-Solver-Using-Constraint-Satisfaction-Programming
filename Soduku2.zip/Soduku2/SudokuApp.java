package Soduku2;

import Soduku2.Assignment;
import Soduku2.DFSSolver;
import Soduku2.MinimumRemainingValue;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

public class SudokuApp {

    public static String TEST
            = "003020600\n"
            + "900305001\n"
            + "001806400\n"
            + "008102900\n"
            + "700000008\n"
            + "006708200\n"
            + "002609500\n"
            + "800203009\n"
            + "005010300";

    private static final JFrame frame = new JFrame("Sudoku solver");
    public static GridSudoku grid;
    public static String fileAsString = new String();
    public static String fileAsString2 = new String();

    public static void main(String[] args) {

        InputStream is = null;
        try {
            is = new FileInputStream("C:\\Users\\PC\\Documents\\NetBeansProjects\\JavaApplication1\\src\\Soduku2\\sudokutext.txt");
            BufferedReader buf = new BufferedReader(new InputStreamReader(is));
            String line;
            try {
                line = buf.readLine();
                String[] lineArray = line.split(",");
                for(int i=0;i<lineArray.length;i++)
                {
                    fileAsString2 = fileAsString2+lineArray[i];
                }
                StringBuilder sb = new StringBuilder();
            while (line != null) {
                sb.append(line).append("\n");
                line = buf.readLine();
                
                
            }
                System.out.println(fileAsString2);
            fileAsString = sb.toString();
                System.out.println(fileAsString);
            } catch (IOException ex) {
                Logger.getLogger(SudokuApp.class.getName()).log(Level.SEVERE, null, ex);
            }
            

        } catch (FileNotFoundException ex) {
            ;
        } 
        
        if(!fileAsString2.isEmpty())
        grid = new GridSudoku(9,fileAsString2);
        else
            grid = new GridSudoku(9);
        frame.getContentPane().add(grid);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setResizable(false);
        centerView();
        frame.setVisible(true);
        //System.out.println(grid.getStr());
        frame.repaint();

    }

    private static void centerView() {
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = frame.getSize();

        frame.setLocation((screen.width - frameSize.width) >> 1,
                (screen.height - frameSize.height) >> 1);
    }

}
